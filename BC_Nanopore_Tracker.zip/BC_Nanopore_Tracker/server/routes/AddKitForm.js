import React, { useState } from 'react';
import axios from 'axios';
import './AddMinion.css'; // reuse modal styles

export default function AddKitForm({ onClose }) {
  const [kitData, setKitData] = useState({
    kit_type: '',
    date_opened: '',
    kit_owner: '',
    num_preps_expected: ''
  });

  const handleChange = e => {
    setKitData({ ...kitData, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    await axios.post('/add-kit', kitData);
    alert('Kit added!');
    onClose();
  };

  return (
    <div className="modal">
      <form className="modal-content" onSubmit={handleSubmit}>
        <h2>Add New Kit</h2>
        {Object.keys(kitData).map(key => (
          <input
            key={key}
            name={key}
            placeholder={key.replace(/_/g, ' ')}
            value={kitData[key]}
            onChange={handleChange}
            type={key.includes('date') ? 'date' : 'text'}
          />
        ))}
        <button type="submit">Submit</button>
        <button type="button" className="close-button" onClick={onClose}>
          Close
        </button>
      </form>
    </div>
  );
}
