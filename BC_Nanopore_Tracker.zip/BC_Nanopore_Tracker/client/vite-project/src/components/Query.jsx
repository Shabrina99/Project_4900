import React, { useState, useEffect } from 'react';
import Nav from "./Nav";
import Edit from './Edit';
import './Query.css';

const Query = () => {
  const [currentPage, setCurrentPage] = useState(1);
  const [keyword, setKeyword] = useState('');
  const [tableName, setTableName] = useState('experiment');
  const [data, setData] = useState([]);
  const [error, setError] = useState(null);
  const [successMessage, setSuccessMessage] = useState(null);
  const [editingRow, setEditingRow] = useState(null);
  const [isLoading, setIsLoading] = useState(false);

  // 🔐 Password confirmation modal states
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [passwordInput, setPasswordInput] = useState('');
  const [selectedRowToDelete, setSelectedRowToDelete] = useState(null);
  const [passwordError, setPasswordError] = useState('');

  const tables = [
    'experiment', 'run', 'barcode', 'computer', 'library_prep',
    'minion', 'operator', 'participant', 'sample', 'sequencing_unit'
  ];

  useEffect(() => {
    fetchData();
  }, [currentPage, tableName, keyword]);

  const fetchData = async () => {
    setIsLoading(true);
    setError(null);
    setSuccessMessage(null);
    try {
      let url = `http://localhost:8000/api/data/${tableName}?page=${currentPage}&limit=20`;
      if (keyword) {
        url += `&search=${encodeURIComponent(keyword)}`;
      }
      const response = await fetch(url);
      const result = await response.json();

      if (response.ok) {
        setData(result);
      } else {
        throw new Error(result.message || 'Error fetching data');
      }
    } catch (error) {
      setError(`Failed to fetch data: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  const handleDelete = async (row) => {
    setIsLoading(true);
    try {
      const url = `http://localhost:8000/api/data/delete/${tableName}/${row.id}`;
      const response = await fetch(url, { method: 'DELETE' });

      if (response.ok) {
        const result = await response.json();
        setData(prevData => prevData.filter(item => item.id !== row.id));
        setSuccessMessage('Row deleted successfully!');
      } else {
        const text = await response.text();
        throw new Error('Failed to delete row');
      }
    } catch (error) {
      setError(`Error: ${error.message}`);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <div className="container">
      <Nav />
      <h1 className="header">Database Query with Search</h1>

      <div className="controls">
        <div>
          <label htmlFor="tableSelect">Select Table:</label>
          <select id="tableSelect" value={tableName} onChange={(e) => {
            setTableName(e.target.value);
            setCurrentPage(1);
            setKeyword('');
          }} className="select">
            {tables.map(table => (
              <option key={table} value={table}>{table}</option>
            ))}
          </select>
        </div>

        <div>
          <input
            type="text"
            value={keyword}
            onChange={(e) => setKeyword(e.target.value)}
            placeholder="Enter keyword to search"
            className="input"
          />
          <button onClick={fetchData} className="button">Search</button>
        </div>
      </div>

      {isLoading ? (
        <p className="loading">Loading...</p>
      ) : error ? (
        <p className="error">{error}</p>
      ) : (
        <>
          {successMessage && <p className="success">{successMessage}</p>}
          <div className="table-container">
            <table className="query-table">
              <thead>
                <tr>
                  {data.length > 0 && Object.keys(data[0]).map(key => (
                    <th key={key} className="query-th">{key}</th>
                  ))}
                  <th className="query-th">Actions</th>
                </tr>
              </thead>
              <tbody>
                {data.map((row, index) => (
                  editingRow === row ? (
                    <Edit
                      key={index}
                      row={row}
                      onSave={async (editedRow) => {
                        setIsLoading(true);
                        try {
                          const response = await fetch(`http://localhost:8000/api/data/${tableName}/${editedRow.id}`, {
                            method: 'PUT',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify(editedRow),
                          });
                          if (response.ok) {
                            setData(prevData => prevData.map(item => item.id === editedRow.id ? editedRow : item));
                            setEditingRow(null);
                            setSuccessMessage('Row updated successfully!');
                          } else {
                            throw new Error('Failed to update data');
                          }
                        } catch (error) {
                          setError(`Error: ${error.message}`);
                        } finally {
                          setIsLoading(false);
                        }
                      }}
                      onCancel={() => setEditingRow(null)}
                    />
                  ) : (
                    <tr key={index}>
                      {Object.values(row).map((value, idx) => (
                        <td key={idx} className="query-td">{value}</td>
                      ))}
                      <td className="query-td">
                        <button onClick={() => setEditingRow(row)} className="edit-button">Edit</button>
                        <button
                          onClick={() => {
                            setSelectedRowToDelete(row);
                            setShowPasswordModal(true);
                            setPasswordInput('');
                            setPasswordError('');
                          }}
                          className="delete-button"
                        >
                          Delete
                        </button>
                      </td>
                    </tr>
                  )
                ))}
              </tbody>
            </table>
          </div>
        </>
      )}

      <div className="pagination">
        <button onClick={() => setCurrentPage(prev => Math.max(prev - 1, 1))} className="pagination-button" disabled={currentPage === 1}>Previous Page</button>
        <span>Page: {currentPage}</span>
        <button onClick={() => setCurrentPage(prev => prev + 1)} className="pagination-button">Next Page</button>
      </div>

      {/* 🔐 Password Confirmation Modal */}
      {showPasswordModal && (
        <div className="modal">
          <div className="modal-content">
            <h3>Confirm Password to Delete</h3>
            <input
              type="password"
              placeholder="Enter your password"
              value={passwordInput}
              onChange={(e) => setPasswordInput(e.target.value)}
            />
            {passwordError && <p className="error">{passwordError}</p>}
            <div className="button-group">
              <button
                className="submit-button"
                onClick={() => {
                  if (passwordInput === 'admin123') {
                    handleDelete(selectedRowToDelete);
                    setShowPasswordModal(false);
                  } else {
                    setPasswordError('Incorrect password.');
                  }
                }}
              >
                Confirm Delete
              </button>
              <button
                className="close-button"
                onClick={() => setShowPasswordModal(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Query;
