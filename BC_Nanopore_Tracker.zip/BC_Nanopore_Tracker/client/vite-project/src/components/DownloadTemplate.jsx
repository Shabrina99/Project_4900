import React from 'react';
import './DownloadTemplate.css';

export default function DownloadTemplate() {
  const handleDownload = () => {
    const csvContent = [
      [
        "sample_code",
        "experiment_code",
        "sample_type",
        "date_collected",
        "location_collected_name",
        "sample_notes",
        "experimenter_name",
        "extraction",
        "date_extracted",
        "dna_extraction_kit",
        "dna_conc_ng_ul",
        "extraction_notes"
      ].join(","),
      [
        "SMP001",
        "1",
        "Blood",
        "2025-04-01",
        "Lab A",
        "Initial test",
        "Dr. Smith",
        "Method A",
        "2025-04-02",
        "Kit A",
        "23.5",
        "All good"
      ].join(",")
    ].join("\n");

    const blob = new Blob([csvContent], { type: "text/csv" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "sample_metadata_template.csv";
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <button className="upload-btn" onClick={handleDownload}>
      Download Sample Metadata Template
    </button>
  );
}
