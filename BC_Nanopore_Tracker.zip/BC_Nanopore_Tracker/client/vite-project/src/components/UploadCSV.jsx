import React, { useState } from 'react';
import Papa from 'papaparse';
import './UploadCSV.css';

function UploadCSV() {
  const [files, setFiles] = useState([]);
  const [activeData, setActiveData] = useState([]);
  const [headers, setHeaders] = useState([]);
  const [message, setMessage] = useState('');
  const [selectedFileName, setSelectedFileName] = useState('');

  const handleChange = (e) => {
    const selectedFiles = Array.from(e.target.files);
    setFiles(selectedFiles);
    setActiveData([]);
    setHeaders([]);
    setSelectedFileName('');
    setMessage('');
  };

  const handlePreview = (file) => {
    if (!file.name.endsWith('.csv')) {
      setMessage('❌ Not a valid CSV file.');
      return;
    }

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: function (results) {
        setHeaders(Object.keys(results.data[0] || {}));
        setActiveData(results.data);
        setSelectedFileName(file.name);
        setMessage(`✅ Previewing ${file.name}`);
      },
      error: function () {
        setMessage('❌ Error parsing CSV file.');
      }
    });
  };

  const handleUpload = async (file) => {
    const formData = new FormData();
    formData.append('csv_file', file);

    try {
      const res = await fetch('http://localhost:8000/api/data/upload-csv', {
        method: 'POST',
        body: formData,
      });
      const result = await res.json();
      if (result.success) {
        setMessage(`✅ ${file.name} uploaded successfully.`);
      } else {
        setMessage(`❌ Upload failed for ${file.name}.`);
      }
    } catch (err) {
      setMessage(`❌ Error uploading ${file.name}.`);
    }
  };

  const handleClear = () => {
    setFiles([]);
    setActiveData([]);
    setHeaders([]);
    setSelectedFileName('');
    setMessage('');
  };

  return (
    <div className="upload-box">
      <h2>Upload and Preview CSV</h2>
      <input type="file" accept=".csv" multiple onChange={handleChange} />
      {message && <p className="message-box">{message}</p>}

      {files.length > 0 && (
        <div className="file-list">
          <ul>
            {files.map((file, index) => (
              <li key={index}>
                <span>{file.name}</span>
                <div>
                  <button className="upload-btn" onClick={() => handlePreview(file)}>Preview</button>
                  <button className="upload-btn" onClick={() => handleUpload(file)}>Save</button>
                </div>
              </li>
            ))}
          </ul>
        </div>
      )}

      <div className="button-group">
        <button className="delete-btn" onClick={handleClear}>Clear All</button>
      </div>

      {activeData.length > 0 && (
        <div className="table-container">
          <h3 style={{ marginBottom: '10px' }}>{selectedFileName}</h3>
          <table className="csv-table">
            <thead>
              <tr>
                {headers.map((header, idx) => (
                  <th key={idx}>{header}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {activeData.map((row, idx) => (
                <tr key={idx}>
                  {headers.map((header, hIdx) => (
                    <td key={hIdx}>{row[header]}</td>
                  ))}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

export default UploadCSV;
